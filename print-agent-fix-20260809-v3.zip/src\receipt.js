'use strict';

const LINE_WIDTH = 32;
const MOJIBAKE_PATTERN = /锛|绔|鎵撳嵃|璁㈠崟|妗屼綅|寰俊|閰掑埜|鍟嗗搧|浼樻儬|瀹炰粯|鍏朵粬|鏈€|涓€鎵|楼|\uFFFD/;

function displayWidth(value) {
  return Array.from(String(value)).reduce(
    (width, char) => width + (char.charCodeAt(0) > 0x7f ? 2 : 1),
    0,
  );
}

function truncate(value, width) {
  let result = '';
  let current = 0;
  for (const char of Array.from(String(value))) {
    const charWidth = char.charCodeAt(0) > 0x7f ? 2 : 1;
    if (current + charWidth > width) break;
    result += char;
    current += charWidth;
  }
  return result;
}

function padEndWidth(value, width) {
  const text = truncate(value, width);
  return text + ' '.repeat(Math.max(0, width - displayWidth(text)));
}

function padStartWidth(value, width) {
  const text = truncate(value, width);
  return ' '.repeat(Math.max(0, width - displayWidth(text))) + text;
}

function center(value) {
  const text = truncate(value, LINE_WIDTH);
  const padding = Math.max(0, Math.floor((LINE_WIDTH - displayWidth(text)) / 2));
  return `${' '.repeat(padding)}${text}`;
}

function money(value) {
  return Number(value || 0).toFixed(2);
}

function paymentMethod(value) {
  const text = String(value || '');
  const normalized = text.toLowerCase();
  if (normalized.includes('wechat') || text.includes('微信') || text.includes('寰俊')) return '微信支付';
  if (normalized.includes('coin') || text.includes('金币') || text.includes('閲戝竵')) return '金币支付';
  if (
    normalized.includes('voucher')
    || text.includes('酒券')
    || text.includes('优惠')
    || text.includes('閰掑埜')
    || text.includes('浼樻儬')
  ) {
    return '酒券支付';
  }
  if (normalized.includes('backend') || text.includes('后台') || text.includes('鍚庡彴')) return '后台确认';
  return text || '其他';
}

function specLabel(value) {
  if (value === 'half_dozen') return '半打';
  if (value === 'dozen') return '一打';
  return '';
}

function normalizeKnownLegacyText(value, fallback = '') {
  const text = String(value || fallback);
  if (text === '鏈€夋嫨妗屼綅') return '未选择桌位';
  if (text === '鍟嗗搧') return '商品';
  return text;
}

function formatItem(item) {
  const quantity = Math.max(0, Number(item.quantity || 0));
  const amount = money(item.amount);
  const spec = specLabel(item.specType);
  const itemName = normalizeKnownLegacyText(item.name, '商品');
  const name = spec ? `${itemName}（${spec}）` : itemName;
  const firstLine = truncate(name, LINE_WIDTH);
  const quantityText = `x${quantity}`;
  const detail = `${padEndWidth(quantityText, 8)}${padStartWidth(`￥${amount}`, LINE_WIDTH - 8)}`;
  return `${firstLine}\n${detail}`;
}

function formatReceipt(payload) {
  const paidAt = new Date(payload.paidAt || Date.now());
  const dateText = Number.isNaN(paidAt.getTime())
    ? String(payload.paidAt || '')
    : paidAt.toLocaleString('zh-CN', {
      hour12: false,
      timeZone: 'Asia/Shanghai',
    });
  const items = Array.isArray(payload.items) ? payload.items : [];
  const divider = '-'.repeat(LINE_WIDTH);
  const lines = [
    center('Set baR'),
    center('订单出品单'),
    divider,
    `桌位：${normalizeKnownLegacyText(payload.tableName, '未选择桌位')}`,
    `订单：${payload.orderNumber || ''}`,
    `时间：${dateText}`,
    divider,
    ...items.flatMap((item) => [formatItem(item), '']),
    divider,
    `${padEndWidth('商品原价', 16)}${padStartWidth(`￥${money(payload.originalAmount)}`, 16)}`,
  ];

  if (Number(payload.discountAmount || 0) > 0) {
    lines.push(
      `${padEndWidth('优惠金额', 16)}${padStartWidth(`-￥${money(payload.discountAmount)}`, 16)}`,
    );
  }

  lines.push(
    `${padEndWidth('实付金额', 16)}${padStartWidth(`￥${money(payload.totalAmount)}`, 16)}`,
    `支付方式：${paymentMethod(payload.paymentMethod)}`,
  );

  if (payload.memberName) lines.push(`会员：${payload.memberName}`);
  if (payload.notes) lines.push(`备注：${payload.notes}`);

  lines.push(divider, center('请及时出品'), '', '', '');
  return lines.join('\n');
}

function assertReceiptIsPrintable(text) {
  const match = String(text || '').match(MOJIBAKE_PATTERN);
  if (match) {
    throw new Error(`小票包含乱码“${match[0]}”，已停止打印以避免浪费纸张`);
  }
}

module.exports = {
  formatReceipt,
  assertReceiptIsPrintable,
  displayWidth,
  truncate,
};
