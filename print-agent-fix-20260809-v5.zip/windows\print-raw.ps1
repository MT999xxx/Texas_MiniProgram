param(
  [Parameter(Mandatory = $true)]
  [string]$PrinterName,

  [Parameter(Mandatory = $true)]
  [string]$TextFile
)

$ErrorActionPreference = 'Stop'

Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;

public static class RawPrinter {
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    public class DOCINFO {
        [MarshalAs(UnmanagedType.LPWStr)] public string pDocName;
        [MarshalAs(UnmanagedType.LPWStr)] public string pOutputFile;
        [MarshalAs(UnmanagedType.LPWStr)] public string pDataType;
    }

    [DllImport("winspool.drv", SetLastError = true, CharSet = CharSet.Unicode)]
    static extern bool OpenPrinter(string printerName, out IntPtr printer, IntPtr defaults);

    [DllImport("winspool.drv", SetLastError = true)]
    static extern bool ClosePrinter(IntPtr printer);

    [DllImport("winspool.drv", SetLastError = true, CharSet = CharSet.Unicode)]
    static extern int StartDocPrinter(IntPtr printer, int level, [In] DOCINFO docInfo);

    [DllImport("winspool.drv", SetLastError = true)]
    static extern bool EndDocPrinter(IntPtr printer);

    [DllImport("winspool.drv", SetLastError = true)]
    static extern bool StartPagePrinter(IntPtr printer);

    [DllImport("winspool.drv", SetLastError = true)]
    static extern bool EndPagePrinter(IntPtr printer);

    [DllImport("winspool.drv", SetLastError = true)]
    static extern bool WritePrinter(IntPtr printer, byte[] bytes, int count, out int written);

    public static void Send(string printerName, byte[] bytes) {
        IntPtr printer;
        if (!OpenPrinter(printerName, out printer, IntPtr.Zero)) {
            throw new System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error());
        }

        try {
            var docInfo = new DOCINFO {
                pDocName = "Set baR Order Receipt",
                pDataType = "RAW"
            };
            if (StartDocPrinter(printer, 1, docInfo) == 0) {
                throw new System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error());
            }

            try {
                if (!StartPagePrinter(printer)) {
                    throw new System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error());
                }

                try {
                    int written;
                    if (!WritePrinter(printer, bytes, bytes.Length, out written) || written != bytes.Length) {
                        throw new System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error());
                    }
                } finally {
                    EndPagePrinter(printer);
                }
            } finally {
                EndDocPrinter(printer);
            }
        } finally {
            ClosePrinter(printer);
        }
    }
}
'@

$text = [System.IO.File]::ReadAllText($TextFile, [System.Text.Encoding]::UTF8)
$encoding = [System.Text.Encoding]::GetEncoding(
  936,
  [System.Text.EncoderReplacementFallback]::new('?'),
  [System.Text.DecoderFallback]::ExceptionFallback
)
$init = [byte[]](
  0x1B, 0x40,
  0x1B, 0x4D, 0x01,
  0x1C, 0x26,
  0x1D, 0x21, 0x00
)
$body = $encoding.GetBytes($text)
$feed = [byte[]](0x0A)
$bytes = New-Object byte[] ($init.Length + $body.Length + $feed.Length)
[Array]::Copy($init, 0, $bytes, 0, $init.Length)
[Array]::Copy($body, 0, $bytes, $init.Length, $body.Length)
[Array]::Copy($feed, 0, $bytes, $init.Length + $body.Length, $feed.Length)

[RawPrinter]::Send($PrinterName, $bytes)
